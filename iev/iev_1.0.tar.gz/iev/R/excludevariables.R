excludevariables <-
function(pattern,samples){  # argument "pattern" is the pathogenic pattern,for example,"[a,b]" denotes the mutation of the SNP a and SNP b;argument "samples" is the data of samples
data<-samples
for(i in (1: length(pattern))){
data<-select(data,-pattern[[i]])
}
write.table(data,file = "data.csv",sep = ",",row.names = FALSE,col.names = TRUE)  # update the data
}
