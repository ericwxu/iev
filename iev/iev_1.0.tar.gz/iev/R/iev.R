iev <-
function(k,consistencythreshold,samples){  # argument "k" is the iterations;argument "samples" is the data of samples
write.table(samples,file = "data.csv",sep = ",",row.names = FALSE,col.names = TRUE)
write.table("pattern",'ievresult.txt',append=T,col.names=F,row.names=F,eol='\t')
write.table("p-value",'ievresult.txt',append=T,col.names=F,row.names=F,eol='\n')
start<-Sys.time()  # start to time
for (i in (1:k)){
snp<-read.csv("data.csv",header = F,skip=1)# read data without column names
qcafit<-try(qcaresultlist<-qcacalculation(consistencythreshold,snp),TRUE)  # qca calculation for the data
if("try-error" %in% class(qcafit)){
break
}else{
if (length(qcaresultlist)==1){break}  # no solution of qca
else{if (length(qcaresultlist)==7){solutionlist<-qcaresultlist[[1]][[1]]}  # some prime implicants are tied 
else {solutionlist<-qcaresultlist[[1]]}}  # no prime implicants are tied
patternwithnum<-extractpattern(solutionlist,snp)
}  # extract pattern from the solution
if (length(patternwithnum)==0){
break}else{
pvalue<-chisquare(patternwithnum,snp)
pattern<-list()  # define a pattern with column
column<-read.csv("data.csv",header = F,nrows=1)  # read the column names
for (i in (1:length(patternwithnum))){
pattern<-c(pattern,column[[patternwithnum[[i]]]])
}
snps<-read.csv("data.csv")  # read data with column names
excludevariables(pattern,snps)  # exclude variables and write to data.csv
write.table(pattern,'ievresult.txt',append=T,col.names=F,row.names=F,eol='\t')
write.table(pvalue,'ievresult.txt',append=T,col.names=F,row.names=F,eol='\n')
}
} 
end<-Sys.time()  # end to time
runtime<-end-start  # calculate the runtime
extracttime<-format(runtime,format="%M")  # extract time
write.table("ievruntime",'ievresult.txt',append=T,col.names=F,row.names=F,eol='\t')
write.table(extracttime,'ievresult.txt',append=T,col.names=F,row.names=F,eol='\n')
finalievresult<-read.csv("ievresult.txt",sep='\t')
#file.remove("data.csv")  # remove the file
file.remove("ievresult.txt")  # remove the file
return(finalievresult)
}
